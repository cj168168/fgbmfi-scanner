FGBMFI SCANNER V1

QR FORMAT:
FGBMFI|001 sampai FGBMFI|200

PENTING:
- Kolom No di Google Sheet tetap angka 1 sampai 200. Tidak perlu diubah menjadi 001.
- Scanner otomatis mengubah hasil QR FGBMFI|001 menjadi memberId=1 sebelum dikirim ke Apps Script.
- FGBMFI|010 menjadi memberId=10.
- FGBMFI|200 menjadi memberId=200.
- Logo FGBMFI sudah ditambahkan ke halaman scanner.

File yang diubah:
1. index.html
2. scanner.js
3. fgbmfi-logo.jpg (baru)
